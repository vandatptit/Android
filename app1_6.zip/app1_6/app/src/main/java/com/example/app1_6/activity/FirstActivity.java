package com.example.app1_6.activity;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.text.HtmlCompat;

import static android.app.PendingIntent.getActivity;

public class FirstActivity extends AppCompatActivity {
    protected Context mContext;
    protected ActionBar actionBar;
    protected Button buttonList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        mContext = this;
        buttonList = findViewById(R.id.btn_right);

        //Set Background for Action Bar
        actionBar = getSupportActionBar();
        Drawable drawable = ContextCompat.getDrawable(mContext,R.drawable.bar_background);
        actionBar.setBackgroundDrawable(drawable);
        //actionBar.setTitle(HtmlCompat.fromHtml("<font color=\"darkGray\">" + getString(R.string.app_name) + "</font>", 0));

        //handle button
        buttonList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ListRecordActivity.class);
                startActivity(intent);
            }
        });
    }
    //Creat menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_option, menu);
        menu.removeItem(R.id.edit);
        menu.removeItem(R.id.sort);
        menu.removeItem(R.id.search);
        menu.removeItem(R.id.volume);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.settings:
                intent = new Intent(this, MainActivity.class);
                this.startActivity(intent);
                return true;
            case R.id.help:
                intent = new Intent(this, SecondActivity.class);
                this.startActivity(intent);
                return true;
            case R.id.about:
//                intent = new Intent(this, MainActivity.class);
//                this.startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
