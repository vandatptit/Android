package com.example.app1_6.activity;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class ListRecordActivity extends AppCompatActivity {
    Context mContext;
    ActionBar actionBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_record);

        mContext = this;

        //Set Action bar
//        Drawable drawableIC = getResources().getDrawable(R.drawable.ic_back);
        actionBar = getSupportActionBar();
        Drawable drawable = ContextCompat.getDrawable(mContext, R.drawable.bar_background);
        actionBar.setDisplayHomeAsUpEnabled(true);
//        actionBar.setHomeAsUpIndicator(drawableIC);
        actionBar.setBackgroundDrawable(drawable);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_option, menu);
        menu.removeItem(R.id.help);
        menu.removeItem(R.id.about);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.edit:
                return true;
            case R.id.sort:
                return true;
            case R.id.settings:
                return true;
            case android.R.id.home:onBackPressed();
                return true;
            default: break;
        }
        return super.onOptionsItemSelected(item);
    }
}
