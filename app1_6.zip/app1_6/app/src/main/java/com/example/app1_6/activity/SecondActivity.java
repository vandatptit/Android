package com.example.myapplicationt;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.app1_6.activity.R;

import java.io.IOException;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    Button btnRecord, btnStop, btnPlay;
    Context mContext = this;
    private MediaRecorder mediaRecorder;
    private int k = 1;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnRecord = findViewById(R.id.btn_record);
        btnStop = findViewById(R.id.btn_stop);
        btnPlay = findViewById(R.id.btn_play);
        btnPlay.setEnabled(false);
        btnStop.setEnabled(false);
        final String outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recording.3gp";

        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        mediaRecorder.setOutputFile(outputFile);
        try {
            mediaRecorder.prepare();

        } catch (IllegalStateException ise) {
            // make something ...
            Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_LONG)
                    .show();
        } catch (IOException ioe) {
            // make something
            Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_LONG)
                    .show();
        }

        btnRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(k == 1) {
                    mediaRecorder.start();
                    k++;
                }
                else {
                    mediaRecorder.resume();
                }

//                try {
//                    mediaRecorder.prepare();
//                    mediaRecorder.start();
//                } catch (IllegalStateException ise) {
//                    // make something ...
//                    Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_LONG)
//                            .show();
//                } catch (IOException ioe) {
//                    // make something
//                    Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_LONG)
//                            .show();
//                }
                btnRecord.setEnabled(false);
                btnStop.setEnabled(true);
                Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_LONG)
                        .show();
            }
        });
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaRecorder.pause();
                //mediaRecorder.release();
                // mediaRecorder = null;
                btnRecord.setEnabled(true);
                btnStop.setEnabled(false);
                btnPlay.setEnabled(true);
                Toast.makeText(getApplicationContext(), "Audio Recorder successfully",
                        Toast.LENGTH_LONG).show();
            }
        });
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaRecorder.release();
                mediaRecorder = null;
                MediaPlayer mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(outputFile);
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                    Toast.makeText(getApplicationContext(), "Playing Audio", Toast.LENGTH_LONG)
                            .show();
                } catch (Exception e) {
                    // make something
                }
            }
        });
    }
}
